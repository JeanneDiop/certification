<h5>Réinitialisation de mot e passe</h5>
   
<p>Vous pouvez réinitialiser votre mot de passe en cliquant sur le lien ci-aprés:</p>
<a href="{{ route('reset.password.get', $token) }}">Réinitialiser</a>